export const GET_READERS = "GET_READERS";
export const GET_ALL_READERS = "GET_ALL_READERS";
