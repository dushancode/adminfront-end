export const GET_BANNER = "GET_BANNER";
